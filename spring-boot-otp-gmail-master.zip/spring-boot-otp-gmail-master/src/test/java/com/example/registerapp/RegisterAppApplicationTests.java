package com.example.registerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
